# CS1555Group05

### Importing Custom Data

1) Place all text files for importing into directory ` project-sample-data `
2)  Run ` python3 export_data.py project-sample-data `
3) All resulting .dat files will be placed into directory ` data ` for use.